import torch
import yaml
import os
from src.data_preprocessing import DataPreprocessor
from src.model import SkinDiseaseCNN
from src.train import Trainer
from src.evaluate import Evaluator

def main():
    # Configuration
    with open('config.yaml', 'r') as file:
        config = yaml.safe_load(file)
    
    # Device configuration
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Data preprocessing
    print("Loading and preprocessing data...")
    preprocessor = DataPreprocessor()
    images, labels = preprocessor.load_images_from_directory(config['data']['data_path'])
    train_loader, val_loader, test_loader = preprocessor.create_data_loaders(images, labels)
    
    print(f"Training samples: {len(train_loader.dataset)}")
    print(f"Validation samples: {len(val_loader.dataset)}")
    print(f"Test samples: {len(test_loader.dataset)}")
    
    # Model initialization
    print("Initializing model...")
    model = SkinDiseaseCNN(config)
    model = model.to(device)
    
    # Print model summary
    print(f"Model: {config['model']['model_name']}")
    print(f"Number of parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    # Training
    print("Starting training...")
    trainer = Trainer(model, train_loader, val_loader, config, device)
    trainer.train()
    
    # Evaluation
    print("Evaluating model...")
    evaluator = Evaluator(model, test_loader, device, config['classes'])
    
    # Load best model
    checkpoint = torch.load('models/trained_models/best_model.pth')
    model.load_state_dict(checkpoint['model_state_dict'])
    
    y_pred, y_true, y_probs = evaluator.evaluate()
    
    # Generate reports and plots
    report = evaluator.generate_classification_report(y_true, y_pred)
    cm = evaluator.plot_confusion_matrix(y_true, y_pred)
    fpr, tpr, roc_auc = evaluator.plot_roc_curves(y_true, y_probs)
    evaluator.plot_sample_predictions(test_loader)
    
    # Calculate overall metrics
    overall_accuracy = (y_pred == y_true).mean()
    print(f"\nOverall Test Accuracy: {overall_accuracy:.4f}")

if __name__ == "__main__":
    main()