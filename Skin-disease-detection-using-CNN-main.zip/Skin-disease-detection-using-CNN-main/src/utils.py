import albumentations as A
from albumentations.pytorch import ToTensorV2
import torch
from torch.utils.data import WeightedRandomSampler
import numpy as np

def get_advanced_augmentations():
    """Return advanced augmentation pipeline"""
    return A.Compose([
        A.Resize(224, 224),
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.5),
        A.RandomRotate90(p=0.5),
        A.ShiftScaleRotate(
            shift_limit=0.1,
            scale_limit=0.2,
            rotate_limit=30,
            p=0.5
        ),
        A.RandomBrightnessContrast(
            brightness_limit=0.3,
            contrast_limit=0.3,
            p=0.5
        ),
        A.HueSaturationValue(
            hue_shift_limit=20,
            sat_shift_limit=30,
            val_shift_limit=20,
            p=0.5
        ),
        A.GaussianBlur(blur_limit=3, p=0.3),
        A.GaussNoise(var_limit=(10.0, 50.0), p=0.3),
        A.CoarseDropout(
            max_holes=8,
            max_height=16,
            max_width=16,
            min_holes=1,
            min_height=8,
            min_width=8,
            fill_value=0,
            p=0.3
        ),
        A.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        ),
        ToTensorV2()
    ])

def create_weighted_sampler(labels):
    """Create weighted sampler for imbalanced datasets"""
    class_counts = np.bincount(labels)
    class_weights = 1. / class_counts
    sample_weights = class_weights[labels]
    sampler = WeightedRandomSampler(
        weights=sample_weights,
        num_samples=len(sample_weights),
        replacement=True
    )
    return sampler

def calculate_metrics(y_true, y_pred, y_probs, average='macro'):
    """Calculate comprehensive evaluation metrics"""
    from sklearn.metrics import (
        accuracy_score, precision_score, recall_score, 
        f1_score, roc_auc_score, cohen_kappa_score
    )
    
    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'precision': precision_score(y_true, y_pred, average=average),
        'recall': recall_score(y_true, y_pred, average=average),
        'f1_score': f1_score(y_true, y_pred, average=average),
        'kappa': cohen_kappa_score(y_true, y_pred)
    }
    
    # AUC for multi-class
    try:
        metrics['auc_ovo'] = roc_auc_score(
            y_true, y_probs, multi_class='ovo', average=average
        )
        metrics['auc_ovr'] = roc_auc_score(
            y_true, y_probs, multi_class='ovr', average=average
        )
    except:
        metrics['auc_ovo'] = 0.0
        metrics['auc_ovr'] = 0.0
    
    return metrics