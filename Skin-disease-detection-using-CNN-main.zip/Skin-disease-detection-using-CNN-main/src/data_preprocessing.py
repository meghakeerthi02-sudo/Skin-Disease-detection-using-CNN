import os
import cv2
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
import albumentations as A
from albumentations.pytorch import ToTensorV2
import torch
from torch.utils.data import Dataset, DataLoader
import yaml

class SkinDiseaseDataset(Dataset):
    def __init__(self, images, labels, transform=None):
        self.images = images
        self.labels = labels
        self.transform = transform
        
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        image = self.images[idx]
        label = self.labels[idx]
        
        if self.transform:
            image = self.transform(image=image)['image']
            
        return image, label

class DataPreprocessor:
    def __init__(self, config_path='config.yaml'):
        with open(config_path, 'r') as file:
            self.config = yaml.safe_load(file)
        
    def load_images_from_directory(self, data_path):
        """Load images and labels from directory structure"""
        images = []
        labels = []
        class_names = self.config['classes']
        
        for class_idx, class_name in enumerate(class_names):
            class_path = os.path.join(data_path, class_name)
            if not os.path.exists(class_path):
                continue
                
            for img_file in os.listdir(class_path):
                if img_file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    img_path = os.path.join(class_path, img_file)
                    image = cv2.imread(img_path)
                    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                    images.append(image)
                    labels.append(class_idx)
        
        return np.array(images), np.array(labels)
    
    def create_data_loaders(self, images, labels):
        """Create train, validation, and test data loaders"""
        # Split data
        X_temp, X_test, y_temp, y_test = train_test_split(
            images, labels, 
            test_size=self.config['data']['test_ratio'],
            stratify=labels,
            random_state=42
        )
        
        val_ratio = self.config['data']['val_ratio'] / (1 - self.config['data']['test_ratio'])
        X_train, X_val, y_train, y_val = train_test_split(
            X_temp, y_temp,
            test_size=val_ratio,
            stratify=y_temp,
            random_state=42
        )
        
        # Define transforms
        train_transform = A.Compose([
            A.Resize(*self.config['data']['image_size']),
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.5),
            A.RandomRotate90(p=0.5),
            A.ShiftScaleRotate(
                shift_limit=0.0625,
                scale_limit=0.1,
                rotate_limit=15,
                p=0.5
            ),
            A.RandomBrightnessContrast(
                brightness_limit=0.2,
                contrast_limit=0.2,
                p=0.5
            ),
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
            ToTensorV2()
        ])
        
        val_transform = A.Compose([
            A.Resize(*self.config['data']['image_size']),
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
            ToTensorV2()
        ])
        
        # Create datasets
        train_dataset = SkinDiseaseDataset(X_train, y_train, train_transform)
        val_dataset = SkinDiseaseDataset(X_val, y_val, val_transform)
        test_dataset = SkinDiseaseDataset(X_test, y_test, val_transform)
        
        # Create data loaders
        batch_size = self.config['data']['batch_size']
        num_workers = self.config['data']['num_workers']
        
        train_loader = DataLoader(
            train_dataset, batch_size=batch_size, shuffle=True, 
            num_workers=num_workers
        )
        val_loader = DataLoader(
            val_dataset, batch_size=batch_size, shuffle=False,
            num_workers=num_workers
        )
        test_loader = DataLoader(
            test_dataset, batch_size=batch_size, shuffle=False,
            num_workers=num_workers
        )
        
        return train_loader, val_loader, test_loader