import torch
import torch.nn as nn
import torchvision.models as models
import timm

class SkinDiseaseCNN(nn.Module):
    def __init__(self, config):
        super(SkinDiseaseCNN, self).__init__()
        self.config = config
        self.num_classes = config['model']['num_classes']
        self.model_name = config['model']['model_name']
        self.pretrained = config['model']['pretrained']
        
        if self.model_name.startswith('efficientnet'):
            self.model = timm.create_model(
                self.model_name, 
                pretrained=self.pretrained,
                num_classes=self.num_classes
            )
        elif self.model_name in ['resnet50', 'resnet101']:
            if self.model_name == 'resnet50':
                self.model = models.resnet50(pretrained=self.pretrained)
            else:
                self.model = models.resnet101(pretrained=self.pretrained)
            
            # Modify the final layer
            num_ftrs = self.model.fc.in_features
            self.model.fc = nn.Sequential(
                nn.Dropout(config['model']['dropout_rate']),
                nn.Linear(num_ftrs, self.num_classes)
            )
        elif self.model_name == 'densenet121':
            self.model = models.densenet121(pretrained=self.pretrained)
            num_ftrs = self.model.classifier.in_features
            self.model.classifier = nn.Sequential(
                nn.Dropout(config['model']['dropout_rate']),
                nn.Linear(num_ftrs, self.num_classes)
            )
        else:
            raise ValueError(f"Unsupported model: {self.model_name}")
    
    def forward(self, x):
        return self.model(x)

class EnsembleModel(nn.Module):
    def __init__(self, models_list):
        super(EnsembleModel, self).__init__()
        self.models = nn.ModuleList(models_list)
        
    def forward(self, x):
        outputs = [model(x) for model in self.models]
        # Average the outputs
        output = torch.stack(outputs).mean(dim=0)
        return output